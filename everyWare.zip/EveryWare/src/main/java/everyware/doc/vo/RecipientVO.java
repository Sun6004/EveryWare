package everyware.doc.vo;

public class RecipientVO {
	private String doc_id  ;
	private String dept_id ;
	private String dept_name;
	
	public String getDoc_id() {
		return doc_id;
	}
	public void setDoc_id(String doc_id) {
		this.doc_id = doc_id;
	}
	public String getDept_id() {
		return dept_id;
	}
	public void setDept_id(String dept_id) {
		this.dept_id = dept_id;
	}
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}
	@Override
	public String toString() {
		return "RecipientVO [doc_id=" + doc_id + ", dept_id=" + dept_id + ", dept_name=" + dept_name + "]";
	}
	
}
