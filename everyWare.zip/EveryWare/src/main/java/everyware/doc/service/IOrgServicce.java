package everyware.doc.service;

import java.util.List;

import everyware.doc.vo.DepartmentVO;

public interface IOrgServicce {
	public List<DepartmentVO> selectAll();
}
