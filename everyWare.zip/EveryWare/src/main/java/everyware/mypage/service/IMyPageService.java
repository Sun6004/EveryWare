package everyware.mypage.service;

import java.util.List;
import java.util.Map;

import everyware.mypage.vo.LogVO;
import groupware.emp.vo.EmployeesVO;

public interface IMyPageService {
	
	public List<LogVO> selectLogList(Map<String, Object> map);
	
	public int updateMyInfo(EmployeesVO vo);
	
}
