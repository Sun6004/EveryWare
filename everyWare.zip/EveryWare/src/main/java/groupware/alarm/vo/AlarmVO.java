package groupware.alarm.vo;

public class AlarmVO {
	private String alarm_id;
	private String emp_id;
	private String alarm_type;
	private String alarm_status;
	private String alarm_date;
	private String alarm_url;
	
	public String getAlarm_id() {
		return alarm_id;
	}
	public void setAlarm_id(String alarm_id) {
		this.alarm_id = alarm_id;
	}
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getAlarm_type() {
		return alarm_type;
	}
	public void setAlarm_type(String alarm_type) {
		this.alarm_type = alarm_type;
	}
	public String getAlarm_status() {
		return alarm_status;
	}
	public void setAlarm_status(String alarm_status) {
		this.alarm_status = alarm_status;
	}
	public String getAlarm_date() {
		return alarm_date;
	}
	public void setAlarm_date(String alarm_date) {
		this.alarm_date = alarm_date;
	}
	public String getAlarm_url() {
		return alarm_url;
	}
	public void setAlarm_url(String alarm_url) {
		this.alarm_url = alarm_url;
	}
}
