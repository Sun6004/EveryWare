//일정별 필터
$("#type_filter").select2({
    placeholder: "일정 규모 선택",
    allowClear: true
});

//datetimepicker
$("#edit-start, #edit-end").datetimepicker({
    format: 'YYYY-MM-DD HH:mm'
});